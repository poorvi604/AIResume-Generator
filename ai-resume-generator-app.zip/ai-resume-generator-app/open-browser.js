const open = require('open');
open('http://localhost:3000');