#!/bin/bash
echo "🚀 Starting Resume Generator..."
npm install
open http://localhost:3000
npm start